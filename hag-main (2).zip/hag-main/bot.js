Commit changes
